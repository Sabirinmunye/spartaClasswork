

function addTwo(n1 , n2) {



}

function addThree(n1, n2, n3) {



}


function multiplyTwo(n1,n2) {




}


function increaseByPercentage(total, percentage) {



}


function reverseWord(word) {



}

function celciusToFahrenheit(celcius) {



}

function fahrenheitToCelcius(fahr) {




}

// BONUS QUESTION
function stripVowels(word) {

  

}


// do not delete
runTests();
