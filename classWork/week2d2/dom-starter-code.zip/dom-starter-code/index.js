var listItems = ["Go out","Come back" , "Buy food" , "Eat food"];


function addListItem(value) {

  

}

// write append loop here


// write the class loop here



